﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace yr10ControlledAssesment
{
    class Program
    {

        public static string[] moderateExcersises = { "Walking", "\nHiking", "\nCleaning", "\nSkateboarding", "\nBasketball" };
        public static string[] highExcersises = { "Running", "\nSwimming", "\nAerobics", "\nFootball", "\nTennis" };
        public static string logDirectory = "C:/Users/97950/Documents/Visual Studio 2012/Projects/YR10controlledassesment/YR10controlledassesment/logs/";

        private static bool running = true;
        static void Main(string[] args)
        {
            

            while (running)
            {
                clientReg();
            }

        }

        private static void clientReg()
        {
            string[] choices = { "1.Enter a new client", "\n2.Options", "\n3.Close" };//Prompts the user to make a choice on what they wish to do
            Console.WriteLine(choices[0] + choices[1] + choices[2]);


            string choice = Console.ReadLine();//creates a string called choice which derives the Console.ReadLine(What reads the user input)

            switch (choice)
            {//switch statement to choice between 3 things fast no BS

                case "1"://first case of the switch
                    Console.Clear();

                    Console.WriteLine("What is your client's first name?");//prints to the console the string submited
                    string firstName = Console.ReadLine();//again creates a string called choice which derives the Console.ReadLine(What reads the user input)
                    Console.Clear();//Clears the console

                    Console.WriteLine("What is your client's last name?");//prints to the console the string submited
                    string lastName = Console.ReadLine();// againn creates a string called choice which derives the Console.ReadLine(What reads the user input)
                    Console.Clear();

                    Console.WriteLine("What is your client's age?");
                    int age = Convert.ToInt32(Console.ReadLine());
                    if (age < 16) {
                        Console.WriteLine("Your client is to young");
                    }
                    else if (age > 64)
                    {
                        Console.WriteLine("Your client is to old");
                    }
                    Console.Clear();

                    string newFileName = firstName + lastName + ".txt";

                    string writeToDir = logDirectory + newFileName;

                    Console.WriteLine("What is your clients height in meters?");
                    string height = (Console.ReadLine());
                    Console.Clear();

                    Console.WriteLine("What is your client's weight in Kilograms?");
                    string weight = (Console.ReadLine());
                    Console.Clear();

                    Console.WriteLine("What is your client's email adress?");
                    string email = Console.ReadLine();
                    Console.Clear();

                    Console.WriteLine("What is your client's exercise intensity?");
                    Console.WriteLine("1.Moderate");
                    Console.WriteLine("2.High");


                    string exerciseIntensity = Console.ReadLine();
                    switch (exerciseIntensity)
                    {
                        case "1":
                            exerciseIntensity = "{Moderate}";
                            File.WriteAllLines(writeToDir, moderateExcersises);
                            break;
                        case "2":
                            exerciseIntensity = "{High}";
                            break;
                    }
                    Console.Clear();

                    try
                    {
                        File.Create(logDirectory + newFileName).Dispose();//creates a new file with the log directory and the file name to store the user data
                        // writes all the strings to a filepath of choice and accesses the substrings to get the first 2 / 3 letters of the string
                        File.WriteAllText(writeToDir, "UserId : " + firstName.Substring(0, 2) + lastName.Substring(0, 3) + ", Age: " + age.ToString() + ", Height: " + height + "m" + ", Weight: " + weight + "Kg" + ", Email: " + email + ", Exercise Intensity: " + exerciseIntensity);

                    }
                    catch (IOException e)
                    {
                        Console.WriteLine(
                            "{0}: The write operation could not " +
                            "be performed because the specified " +
                            "part of the file is locked.",
                            e.GetType().Name);
                    }


                    using (StreamReader reader = File.OpenText(writeToDir))//streamreader reads from a byte stream (the writeToDir)
                    {
                        string s = "";
                        while ((s = reader.ReadLine()) != null)
                        {
                            Console.WriteLine(s);
                            Console.WriteLine("Is This Infomation Correct?");
                            Console.WriteLine("1.Yes");
                            Console.WriteLine("2.No");

                        }


                    }
                    string Ichoice = Console.ReadLine();
                    switch (Ichoice)
                    {
                        case "1":


                            System.Diagnostics.Process.Start(writeToDir);//starts the writeToDir(.txt)

                            break;
                        case "2":
                            File.Delete(writeToDir);//deletesthe writeToDir(.txt)
                            break;
                    }

                    break;//breaks
                case "2":

                    //addstuff
                    break;

                case"3":
                   Environment.Exit(0);//closes the application
                   break;


            }

            //just to stop console from closing
            Console.ReadKey(); 
        }
    }
}
